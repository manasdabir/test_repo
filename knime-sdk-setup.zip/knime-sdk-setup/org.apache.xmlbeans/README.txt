This plug-in contains the JARs from Apache XML Beans for use in Eclipse.
