In order to add the manifest to an executable execute the following command:

> mt.exe -manifest knime.exe.manifest -outputresource:knime.exe;1

Both files must be in the same directory.